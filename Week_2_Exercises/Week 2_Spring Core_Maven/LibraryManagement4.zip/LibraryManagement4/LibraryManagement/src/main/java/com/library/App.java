package com.library;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Configureation of Maven Compiler Plugin for Java version 1.8 " );
        
        
    }
}
