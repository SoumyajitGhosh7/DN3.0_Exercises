package com.library;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.library.repository.BookRepository;
import com.library.service.BookService;

/**
 * Hello world!
 *
 */
public class LibraryManagementApplication 
{
    public static void main( String[] args )
    {
        @SuppressWarnings("resource")
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
        
        BookRepository bookRepoObj=context.getBean("bookRepo",BookRepository.class);
        BookService bookServiceObj=context.getBean("bookService",BookService.class);
        
        //test configuration
        bookRepoObj.testBookRepository();
        bookServiceObj.testBookService();
        
        
    }
}
