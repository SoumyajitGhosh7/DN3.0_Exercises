package com.library.service;

public class BookService {
	public void testBookService() {
		System.out.println("BookService works correctly");
	}
}
