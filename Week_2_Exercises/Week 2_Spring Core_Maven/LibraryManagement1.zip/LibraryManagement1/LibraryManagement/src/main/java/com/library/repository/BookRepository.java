package com.library.repository;

public class BookRepository {
	public void testBookRepository() {
		System.out.println("BookRepository works correctly");
	}
}
