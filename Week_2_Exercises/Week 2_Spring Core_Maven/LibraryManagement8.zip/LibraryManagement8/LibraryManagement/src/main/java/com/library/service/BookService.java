package com.library.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.library.repository.BookRepository;

@Service
public class BookService {
	private BookRepository bookRepoSetter;
	private BookRepository bookRepoConstructor;
    @Autowired
    public BookService(BookRepository bookRepoConstructor) {
        this.bookRepoConstructor = bookRepoConstructor;
    }
	
	public BookRepository getBookRepoSetter() {
		return bookRepoSetter;
	}
	public void setBookRepoSetter(BookRepository bookRepoSetter) {
		this.bookRepoSetter = bookRepoSetter;
	}

    

    
}