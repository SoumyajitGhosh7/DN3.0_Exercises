package com.library.service;

import org.springframework.stereotype.Service;

import com.library.repository.BookRepository;
@Service
public class BookService {
	private BookRepository bookRepoSetter;
	private BookRepository bookRepoConstructor;
	
	
	public BookService(BookRepository bookRepoConstructor) {
		this.bookRepoConstructor = bookRepoConstructor;
		//test constructor injection
		System.out.println("while construction injection");
	}
	
	


	public void setBookRepoSetter(BookRepository bookRepoSetter) {
		this.bookRepoSetter = bookRepoSetter;
		//test setter injection
		System.out.println("while setter injection");
	}



	//testing method
	@Override
	public String toString() {
		return "BookService [bookRepoSetter=" + bookRepoSetter + ", bookRepoConstructor=" + bookRepoConstructor + "]";
	}


	
}
