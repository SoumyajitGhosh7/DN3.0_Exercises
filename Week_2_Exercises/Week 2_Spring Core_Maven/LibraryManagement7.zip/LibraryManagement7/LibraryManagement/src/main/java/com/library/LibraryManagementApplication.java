package com.library;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//import com.library.repository.BookRepository;
import com.library.service.BookService;

/**
 * Hello world!
 *
 */
public class LibraryManagementApplication 
{
    public static void main( String[] args )
    {
        
		@SuppressWarnings("resource")
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		
		
        BookService bookServiceObj=context.getBean(BookService.class);
        
        
        
        //test configuration
       System.out.println("BookService -->  "+bookServiceObj.toString());
       
      
    }
}
