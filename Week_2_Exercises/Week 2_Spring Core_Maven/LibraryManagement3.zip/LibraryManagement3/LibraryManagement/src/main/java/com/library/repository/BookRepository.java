package com.library.repository;

public class BookRepository {
	//test
	public void perfromOperation() {
		System.out.println("Operation Ongoing...\n");
	}
}
