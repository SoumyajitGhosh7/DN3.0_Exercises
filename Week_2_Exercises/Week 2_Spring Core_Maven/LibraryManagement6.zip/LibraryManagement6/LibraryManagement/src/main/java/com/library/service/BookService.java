package com.library.service;

import org.springframework.stereotype.Service;

@Service
public class BookService {
	public void testBookService() {
		System.out.println("BookService works correctly");
	}
}
