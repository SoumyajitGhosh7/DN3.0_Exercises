package com.library.service;

import com.library.repository.BookRepository;

public class BookService {
	
	private BookRepository bookRepository;
	
	
	public void setBookRepository(BookRepository bookRepository) {
		//this is for testing dependency injection
		System.out.println("dependency injection...");
		this.bookRepository = bookRepository;
	}

	//Test
	@Override
	public String toString() {
		return "BookService [bookRepository=" + bookRepository + "]";
	}


	
}
